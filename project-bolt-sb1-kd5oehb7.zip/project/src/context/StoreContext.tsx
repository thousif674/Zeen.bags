import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { PRODUCTS, type Product } from '../data/products';

export interface CartItem {
  product: Product;
  quantity: number;
}

export type Page =
  | 'home'
  | 'shop'
  | 'product'
  | 'wishlist'
  | 'cart'
  | 'login'
  | 'about'
  | 'faq'
  | 'contact';

interface StoreContextType {
  page: Page;
  productId: number | null;
  navigate: (page: Page, productId?: number) => void;
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartTotal: number;
  wishlist: number[];
  toggleWishlist: (productId: number) => void;
  isWishlisted: (productId: number) => boolean;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  user: { name: string; email: string } | null;
  login: (name: string, email: string) => void;
  logout: () => void;
  toast: string | null;
  showToast: (msg: string) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [page, setPage] = useState<Page>('home');
  const [productId, setProductId] = useState<number | null>(null);
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('zeen_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [wishlist, setWishlist] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('zeen_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [user, setUser] = useState<{ name: string; email: string } | null>(() => {
    try {
      const saved = localStorage.getItem('zeen_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('zeen_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('zeen_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    if (user) localStorage.setItem('zeen_user', JSON.stringify(user));
    else localStorage.removeItem('zeen_user');
  }, [user]);

  const navigate = (p: Page, pid?: number) => {
    setPage(p);
    if (pid !== undefined) setProductId(pid);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  const addToCart = (product: Product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.product.id === product.id);
      if (existing) {
        return prev.map((i) =>
          i.product.id === product.id ? { ...i, quantity: i.quantity + quantity } : i
        );
      }
      return [...prev, { product, quantity }];
    });
    showToast(`${product.name} added to cart`);
  };

  const removeFromCart = (id: number) => {
    setCart((prev) => prev.filter((i) => i.product.id !== id));
  };

  const updateQuantity = (id: number, quantity: number) => {
    if (quantity < 1) return;
    setCart((prev) =>
      prev.map((i) => (i.product.id === id ? { ...i, quantity } : i))
    );
  };

  const clearCart = () => setCart([]);

  const toggleWishlist = (id: number) => {
    setWishlist((prev) => {
      if (prev.includes(id)) {
        showToast('Removed from wishlist');
        return prev.filter((w) => w !== id);
      }
      showToast('Added to wishlist');
      return [...prev, id];
    });
  };

  const isWishlisted = (id: number) => wishlist.includes(id);

  const login = (name: string, email: string) => {
    setUser({ name, email });
    showToast(`Welcome, ${name}!`);
  };

  const logout = () => {
    setUser(null);
    showToast('Logged out successfully');
  };

  const cartCount = cart.reduce((sum, i) => sum + i.quantity, 0);
  const cartTotal = cart.reduce((sum, i) => sum + i.product.price * i.quantity, 0);

  return (
    <StoreContext.Provider
      value={{
        page,
        productId,
        navigate,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartCount,
        cartTotal,
        wishlist,
        toggleWishlist,
        isWishlisted,
        searchQuery,
        setSearchQuery,
        user,
        login,
        logout,
        toast,
        showToast,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}

export function getProductById(id: number | null): Product | undefined {
  if (id === null) return undefined;
  return PRODUCTS.find((p) => p.id === id);
}
