export type Category =
  | 'Tote Bags'
  | 'Shoulder Bags'
  | 'Satchel Bags'
  | 'Crossbody Bags'
  | 'Clutch Bags'
  | 'Party Bags'
  | 'Office Handbags'
  | 'Casual Handbags'
  | 'Designer Handbags';

export interface Product {
  id: number;
  name: string;
  category: Category;
  price: number;
  originalPrice: number;
  discount: number;
  rating: number;
  reviews: number;
  image: string;
  images: string[];
  description: string;
  colors: string[];
  material: string;
  tags: string[];
  isNew?: boolean;
  isBestSeller?: boolean;
  isTrending?: boolean;
  isFeatured?: boolean;
}

export const CATEGORIES: Category[] = [
  'Tote Bags',
  'Shoulder Bags',
  'Satchel Bags',
  'Crossbody Bags',
  'Clutch Bags',
  'Party Bags',
  'Office Handbags',
  'Casual Handbags',
  'Designer Handbags',
];

const handbagImages = [
  // Tote Bags
  'https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/904350/pexels-photo-904350.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=800',
  // Shoulder Bags
  'https://images.pexels.com/photos/7679487/pexels-photo-7679487.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/1306248/pexels-photo-1306248.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/2735840/pexels-photo-2735840.jpeg?auto=compress&cs=tinysrgb&w=800',
  // Satchel Bags
  'https://images.pexels.com/photos/298863/pexels-photo-298863.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/1435779/pexels-photo-1435779.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/1669756/pexels-photo-1669756.jpeg?auto=compress&cs=tinysrgb&w=800',
  // Crossbody Bags
  'https://images.pexels.com/photos/298864/pexels-photo-298864.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/2850890/pexels-photo-2850890.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/4759554/pexels-photo-4759554.jpeg?auto=compress&cs=tinysrgb&w=800',
  // Clutch Bags
  'https://images.pexels.com/photos/1461600/pexels-photo-1461600.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/1079881/pexels-photo-1079881.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/3026389/pexels-photo-3026389.jpeg?auto=compress&cs=tinysrgb&w=800',
  // Party Bags
  'https://images.pexels.com/photos/1383490/pexels-photo-1383490.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/2291462/pexels-photo-2291462.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/2042194/pexels-photo-2042194.jpeg?auto=compress&cs=tinysrgb&w=800',
  // Office Handbags
  'https://images.pexels.com/photos/2862835/pexels-photo-2862835.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/428340/pexels-photo-428340.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/2066154/pexels-photo-2066154.jpeg?auto=compress&cs=tinysrgb&w=800',
  // Casual Handbags
  'https://images.pexels.com/photos/2529786/pexels-photo-2529786.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/3769695/pexels-photo-3769695.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/3260704/pexels-photo-3260704.jpeg?auto=compress&cs=tinysrgb&w=800',
  // Designer Handbags
  'https://images.pexels.com/photos/1916797/pexels-photo-1916797.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/3889129/pexels-photo-3889129.jpeg?auto=compress&cs=tinysrgb&w=800',
  'https://images.pexels.com/photos/601642/pexels-photo-601642.jpeg?auto=compress&cs=tinysrgb&w=800',
  // Additional unique images
  'https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/904350/pexels-photo-904350.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/7679487/pexels-photo-7679487.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/1306248/pexels-photo-1306248.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/2735840/pexels-photo-2735840.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/298863/pexels-photo-298863.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/1435779/pexels-photo-1435779.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/1669756/pexels-photo-1669756.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/298864/pexels-photo-298864.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/2850890/pexels-photo-2850890.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/4759554/pexels-photo-4759554.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/1461600/pexels-photo-1461600.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/1079881/pexels-photo-1079881.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/3026389/pexels-photo-3026389.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/1383490/pexels-photo-1383490.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/2291462/pexels-photo-2291462.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/2042194/pexels-photo-2042194.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/2862835/pexels-photo-2862835.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/428340/pexels-photo-428340.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/2066154/pexels-photo-2066154.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/2529786/pexels-photo-2529786.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/3769695/pexels-photo-3769695.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/3260704/pexels-photo-3260704.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/1916797/pexels-photo-1916797.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/3889129/pexels-photo-3889129.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
  'https://images.pexels.com/photos/601642/pexels-photo-601642.jpeg?auto=compress&cs=tinysrgb&w=600&h=750',
];

const colorOptions = [
  ['Tan', 'Brown', 'Black'],
  ['Maroon', 'Gold', 'Beige'],
  ['Black', 'Navy', 'Burgundy'],
  ['Cream', 'Rose', 'Olive'],
  ['Wine', 'Bronze', 'Charcoal'],
  ['Mustard', 'Brown', 'Teal'],
];

const materials = [
  'Genuine Leather',
  'Vegan Leather',
  'Suede Finish',
  'Embossed Leather',
  'Patent Leather',
  'Handcrafted Leather',
];

const descriptions = [
  'Exquisitely handcrafted from premium leather, this bag blends traditional Indian artistry with modern elegance. Perfect for the woman who values both style and substance.',
  'A timeless piece featuring intricate detailing and a spacious interior. Designed for the modern Indian woman who carries her world with grace.',
  'Luxurious texture meets functional design in this stunning handbag. The gold-tone accents elevate any outfit, making it perfect for both daily use and special occasions.',
  'Inspired by India\'s rich heritage of craftsmanship, this bag showcases delicate embroidery and superior finishing. A true statement of affordable luxury.',
  'Meticulously designed with attention to every detail, this handbag offers the perfect balance of elegance and practicality. Carry your essentials in style.',
  'A celebration of feminine grace, this bag features a silhouette that complements both ethnic and contemporary outfits. Crafted to last, designed to impress.',
];

const productNames = [
  'Aishwarya Tote', 'Mira Shoulder Bag', 'Anaya Satchel', 'Diya Crossbody',
  'Riya Clutch', 'Saanvi Party Bag', 'Priya Office Tote', 'Kavya Casual Bag',
  'Lakshmi Designer Bag', 'Meera Shoulder Bag', 'Roshni Tote', 'Tara Satchel',
  'Isha Crossbody', 'Nisha Clutch', 'Pooja Party Bag', 'Sneha Office Bag',
  'Aditi Casual Tote', 'Bhavya Designer Bag', 'Charvi Shoulder Bag', 'Divya Satchel',
  'Esha Crossbody', 'Falguni Clutch', 'Gauri Party Bag', 'Hema Office Bag',
  'Jhanvi Casual Bag', 'Kriti Designer Tote', 'Lavanya Shoulder Bag', 'Madhuri Satchel',
  'Nandini Crossbody', 'Ojaswi Clutch', 'Parul Party Bag', 'Qabila Office Bag',
  'Rekha Casual Bag', 'Sakshi Designer Bag', 'Tanvi Shoulder Tote', 'Urmila Satchel',
  'Vani Crossbody', 'Waheeda Clutch', 'Xenia Party Bag', 'Yamini Office Bag',
  'Zara Casual Bag', 'Arya Designer Bag', 'Bhoomi Shoulder Bag', 'Chitra Satchel',
  'Damini Crossbody', 'Ela Clutch', 'Farah Party Bag', 'Gargi Office Bag',
  'Harita Casual Bag', 'Indira Designer Bag',
];

const categoryMap: Category[] = [
  'Tote Bags', 'Shoulder Bags', 'Satchel Bags', 'Crossbody Bags',
  'Clutch Bags', 'Party Bags', 'Office Handbags', 'Casual Handbags',
  'Designer Handbags',
];

function roundTo(n: number, step: number) {
  return Math.round(n / step) * step;
}

export const PRODUCTS: Product[] = productNames.map((name, i) => {
  const category = categoryMap[i % categoryMap.length];
  const price = roundTo(499 + ((i * 137) % 1500), 10);
  const originalPrice = roundTo(price * (1.25 + ((i % 5) * 0.1)), 10);
  const discount = Math.round(((originalPrice - price) / originalPrice) * 100);
  const rating = Math.round((3.8 + ((i * 7) % 13) / 10) * 10) / 10;
  const reviews = 20 + ((i * 31) % 280);
  const image = handbagImages[i % handbagImages.length];
  const images = [
    handbagImages[i % handbagImages.length],
    handbagImages[(i + 1) % handbagImages.length],
    handbagImages[(i + 2) % handbagImages.length],
    handbagImages[(i + 3) % handbagImages.length],
  ];

  return {
    id: i + 1,
    name,
    category,
    price,
    originalPrice,
    discount,
    rating,
    reviews,
    image,
    images,
    description: descriptions[i % descriptions.length],
    colors: colorOptions[i % colorOptions.length],
    material: materials[i % materials.length],
    tags: [category, 'Premium', 'Handcrafted'],
    isNew: i % 7 === 0,
    isBestSeller: i % 5 === 0,
    isTrending: i % 4 === 0,
    isFeatured: i % 3 === 0,
  };
});

export function formatINR(amount: number): string {
  return '₹' + amount.toLocaleString('en-IN');
}
