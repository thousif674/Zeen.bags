import { StoreProvider, useStore } from './context/StoreContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import FloatingButtons from './components/FloatingButtons';
import Toast from './components/Toast';
import Loader from './components/Loader';
import Home from './pages/Home';
import Shop from './pages/Shop';
import ProductDetails from './pages/ProductDetails';
import Wishlist from './pages/Wishlist';
import Cart from './pages/Cart';
import Login from './pages/Login';
import About from './pages/About';
import FAQ from './pages/FAQ';
import Contact from './pages/Contact';

function PageRouter() {
  const { page } = useStore();

  switch (page) {
    case 'home':
      return <Home />;
    case 'shop':
      return <Shop />;
    case 'product':
      return <ProductDetails />;
    case 'wishlist':
      return <Wishlist />;
    case 'cart':
      return <Cart />;
    case 'login':
      return <Login />;
    case 'about':
      return <About />;
    case 'faq':
      return <FAQ />;
    case 'contact':
      return <Contact />;
    default:
      return <Home />;
  }
}

function AppContent() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <PageRouter />
      </main>
      <Footer />
      <FloatingButtons />
      <Toast />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Loader />
      <AppContent />
    </StoreProvider>
  );
}
