import { useState } from 'react';
import { ChevronDown, HelpCircle, MessageCircle } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { SectionHeading } from '../components/SectionHeading';

const faqCategories = [
  {
    title: 'Orders & Shipping',
    questions: [
      { q: 'How long does delivery take?', a: 'Orders are processed within 1-2 business days and typically delivered within 3-7 business days across India. Remote areas may take additional time.' },
      { q: 'Do you offer free shipping?', a: 'Yes! We offer free shipping on all orders above ₹999. For orders below ₹999, a flat shipping fee of ₹49 applies.' },
      { q: 'How can I track my order?', a: 'Once your order is shipped, you will receive a tracking number via email and SMS. You can use this to track your package in real time.' },
      { q: 'Do you ship internationally?', a: 'Currently, we only ship within India. We are working on expanding our shipping to international locations soon.' },
    ],
  },
  {
    title: 'Returns & Refunds',
    questions: [
      { q: 'What is your return policy?', a: 'We offer a 7-day easy return policy. If you are not satisfied with your purchase, you can return it within 7 days of delivery for a full refund or exchange.' },
      { q: 'How do I initiate a return?', a: 'Simply contact our customer support via WhatsApp or phone with your order details. We will guide you through the return process.' },
      { q: 'When will I receive my refund?', a: 'Refunds are processed within 3-5 business days after we receive and inspect the returned item. The amount will be credited to your original payment method.' },
      { q: 'Can I exchange a product?', a: 'Yes, you can exchange a product within 7 days of delivery, provided it is unused and in its original packaging with all tags intact.' },
    ],
  },
  {
    title: 'Products & Quality',
    questions: [
      { q: 'Are your bags made of genuine leather?', a: 'We offer a variety of materials including genuine leather, vegan leather, and premium synthetic materials. Each product description specifies the material used.' },
      { q: 'How do I care for my handbag?', a: 'Keep your bag away from water and direct sunlight. Clean with a soft, dry cloth. For leather bags, use a leather conditioner occasionally to maintain suppleness.' },
      { q: 'Are the colors accurate in the photos?', a: 'We strive to display colors as accurately as possible. However, slight variations may occur due to lighting and screen settings.' },
      { q: 'Do you offer a warranty?', a: 'Yes, all our handbags come with a 30-day quality warranty against manufacturing defects. Contact us if you encounter any issues.' },
    ],
  },
  {
    title: 'Account & Payment',
    questions: [
      { q: 'How do I create an account?', a: 'Click on the Login/Register button at the top right of the page and fill in your details. It takes less than a minute!' },
      { q: 'What payment methods do you accept?', a: 'We accept all major credit/debit cards, UPI, net banking, and popular digital wallets. All payments are processed securely.' },
      { q: 'Is my payment information secure?', a: 'Absolutely. We use industry-standard encryption to protect your payment information. We never store your card details on our servers.' },
      { q: 'Can I modify or cancel my order?', a: 'Orders can be modified or cancelled within 2 hours of placing them. Contact our support team immediately for assistance.' },
    ],
  },
];

export default function FAQ() {
  const { navigate } = useStore();
  const [openId, setOpenId] = useState<string | null>('0-0');

  const toggle = (catIdx: number, qIdx: number) => {
    const id = `${catIdx}-${qIdx}`;
    setOpenId(openId === id ? null : id);
  };

  return (
    <div>
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Frequently Asked Questions" subtitle="Everything you need to know about ZEEN BAGS" />
        </div>
      </section>

      <section className="pb-20">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          {faqCategories.map((cat, catIdx) => (
            <div key={catIdx} className="mb-10">
              <div className="mb-4 flex items-center gap-3">
                <HelpCircle size={22} className="text-gold" />
                <h3 className="font-display text-xl font-semibold text-gold">{cat.title}</h3>
                <div className="gold-divider flex-1" />
              </div>
              <div className="space-y-3">
                {cat.questions.map((item, qIdx) => {
                  const id = `${catIdx}-${qIdx}`;
                  const isOpen = openId === id;
                  return (
                    <div
                      key={qIdx}
                      className={`accordion-item glass-card rounded-xl overflow-hidden transition-all ${isOpen ? 'open' : ''}`}
                    >
                      <button
                        onClick={() => toggle(catIdx, qIdx)}
                        className="flex w-full items-center justify-between gap-4 p-5 text-left"
                      >
                        <span className="font-body text-base font-medium text-cream">{item.q}</span>
                        <ChevronDown size={20} className={`accordion-icon shrink-0 text-gold ${isOpen ? 'rotate-180' : ''}`} />
                      </button>
                      <div className="accordion-content px-5">
                        <p className="font-body text-sm leading-relaxed text-cream/70">{item.a}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Still have questions */}
          <div className="glass-card rounded-2xl p-8 text-center">
            <h3 className="font-display text-2xl font-bold text-cream">Still Have Questions?</h3>
            <p className="mt-2 text-cream/60">Our support team is here to help you 24/7</p>
            <div className="mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <a
                href="https://wa.me/918248278649?text=Hello%20ZEEN%20BAGS%2C%20I%20have%20a%20question."
                target="_blank"
                rel="noopener noreferrer"
                className="btn-gold flex items-center gap-2"
              >
                <MessageCircle size={18} /> Chat on WhatsApp
              </a>
              <button onClick={() => navigate('contact')} className="btn-outline-gold">
                Contact Us
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
