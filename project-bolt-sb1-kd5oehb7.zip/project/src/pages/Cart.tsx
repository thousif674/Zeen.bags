import { Minus, Plus, Trash2, ShoppingBag, ArrowRight, Tag } from 'lucide-react';
import { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { formatINR } from '../data/products';
import { SectionHeading } from '../components/SectionHeading';

export default function Cart() {
  const { cart, updateQuantity, removeFromCart, cartTotal, navigate, clearCart } = useStore();
  const [coupon, setCoupon] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState(0);
  const [couponMsg, setCouponMsg] = useState('');

  const applyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (coupon.toUpperCase() === 'ZEEN10') {
      setAppliedDiscount(10);
      setCouponMsg('Coupon applied! 10% discount');
    } else {
      setAppliedDiscount(0);
      setCouponMsg('Invalid coupon code');
    }
    setTimeout(() => setCouponMsg(''), 3000);
  };

  const discount = Math.round((cartTotal * appliedDiscount) / 100);
  const shipping = cartTotal > 999 || cartTotal === 0 ? 0 : 49;
  const finalTotal = cartTotal - discount + shipping;

  if (cart.length === 0) {
    return (
      <div>
        <section className="py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <SectionHeading title="Shopping Cart" subtitle="Review your selected items" />
          </div>
        </section>
        <div className="flex min-h-[50vh] flex-col items-center justify-center px-4">
          <div className="flex h-24 w-24 items-center justify-center rounded-full border-2 border-gold/30 bg-gold/5">
            <ShoppingBag size={40} className="text-gold/50" />
          </div>
          <h3 className="mt-6 font-display text-2xl font-bold text-cream">Your cart is empty</h3>
          <p className="mt-2 text-cream/50">Add some beautiful bags to your cart.</p>
          <button onClick={() => navigate('shop')} className="btn-gold mt-6">
            Start Shopping
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Shopping Cart" subtitle={`${cart.length} ${cart.length === 1 ? 'item' : 'items'} in your cart`} />
        </div>
      </section>

      <section className="pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-3">
            {/* Items */}
            <div className="lg:col-span-2">
              <div className="space-y-4">
                {cart.map((item) => (
                  <div key={item.product.id} className="glass-card flex gap-4 rounded-2xl p-4">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="h-28 w-24 shrink-0 rounded-xl object-cover"
                    />
                    <div className="flex flex-1 flex-col">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-[11px] tracking-widest text-gold/70 uppercase">{item.product.category}</p>
                          <h4
                            onClick={() => navigate('product', item.product.id)}
                            className="cursor-pointer font-display text-base font-semibold text-cream hover:text-gold"
                          >
                            {item.product.name}
                          </h4>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          className="text-cream/40 transition-colors hover:text-red-400"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>

                      <div className="mt-2 flex items-baseline gap-2">
                        <span className="font-display text-lg font-bold text-gold">{formatINR(item.product.price)}</span>
                        <span className="text-sm text-cream/40 line-through">{formatINR(item.product.originalPrice)}</span>
                      </div>

                      <div className="mt-auto flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <button onClick={() => updateQuantity(item.product.id, item.quantity - 1)} className="qty-btn !h-8 !w-8">
                            <Minus size={14} />
                          </button>
                          <span className="w-8 text-center font-semibold text-cream">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.product.id, item.quantity + 1)} className="qty-btn !h-8 !w-8">
                            <Plus size={14} />
                          </button>
                        </div>
                        <span className="font-body text-sm font-semibold text-cream">
                          {formatINR(item.product.price * item.quantity)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex justify-between">
                <button onClick={() => navigate('shop')} className="btn-outline-gold !py-2.5 text-sm">
                  Continue Shopping
                </button>
                <button onClick={clearCart} className="text-sm text-cream/50 transition-colors hover:text-red-400">
                  Clear Cart
                </button>
              </div>
            </div>

            {/* Summary */}
            <div>
              <div className="sticky top-28 glass-card rounded-2xl p-6">
                <h3 className="font-display text-lg font-semibold text-gold">Order Summary</h3>
                <div className="gold-divider mt-3" />

                {/* Coupon */}
                <form onSubmit={applyCoupon} className="mt-5">
                  <label className="text-xs font-body text-cream/60">Have a coupon code?</label>
                  <div className="mt-2 flex gap-2">
                    <div className="flex flex-1 items-center gap-2 rounded-xl border border-gold/20 bg-cream/5 px-3">
                      <Tag size={16} className="text-gold/60" />
                      <input
                        type="text"
                        value={coupon}
                        onChange={(e) => setCoupon(e.target.value)}
                        placeholder="ZEEN10"
                        className="w-full bg-transparent py-2.5 text-sm text-cream placeholder:text-cream/40 focus:outline-none"
                      />
                    </div>
                    <button type="submit" className="btn-outline-gold !px-4 !py-2.5 text-sm">Apply</button>
                  </div>
                  {couponMsg && (
                    <p className={`mt-2 text-xs ${appliedDiscount > 0 ? 'text-green-400' : 'text-red-400'}`}>{couponMsg}</p>
                  )}
                </form>

                {/* Totals */}
                <div className="mt-6 space-y-3 border-t border-gold/10 pt-5">
                  <div className="flex justify-between text-sm">
                    <span className="text-cream/60">Subtotal</span>
                    <span className="font-semibold text-cream">{formatINR(cartTotal)}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-cream/60">Discount ({appliedDiscount}%)</span>
                      <span className="font-semibold text-green-400">-{formatINR(discount)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm">
                    <span className="text-cream/60">Shipping</span>
                    <span className="font-semibold text-cream">{shipping === 0 ? 'FREE' : formatINR(shipping)}</span>
                  </div>
                  {shipping > 0 && (
                    <p className="text-xs text-gold/60">Add {formatINR(999 - cartTotal)} more for free shipping!</p>
                  )}
                </div>

                <div className="mt-5 flex justify-between border-t border-gold/10 pt-5">
                  <span className="font-display text-lg font-bold text-cream">Total</span>
                  <span className="font-display text-2xl font-bold text-gold">{formatINR(finalTotal)}</span>
                </div>

                <button className="btn-gold mt-6 flex w-full items-center justify-center gap-2">
                  Proceed to Checkout <ArrowRight size={18} />
                </button>

                <div className="mt-4 flex items-center justify-center gap-2 text-xs text-cream/40">
                  <span>Secure checkout powered by</span>
                  <span className="font-semibold text-gold">ZEEN BAGS</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
