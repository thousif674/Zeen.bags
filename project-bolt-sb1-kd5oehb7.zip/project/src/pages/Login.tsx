import { useState } from 'react';
import { User, Mail, Lock, Eye, EyeOff, Sparkles } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { SectionHeading } from '../components/SectionHeading';

export default function Login() {
  const { login, logout, user, navigate } = useStore();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (mode === 'register' && !name.trim()) errs.name = 'Name is required';
    if (!email.trim()) errs.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(email)) errs.email = 'Invalid email format';
    if (!password.trim()) errs.password = 'Password is required';
    else if (password.length < 6) errs.password = 'Password must be at least 6 characters';

    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    const finalName = mode === 'register' ? name : email.split('@')[0];
    login(finalName, email);
    setTimeout(() => navigate('home'), 1000);
  };

  if (user) {
    return (
      <div>
        <section className="py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <SectionHeading title="My Account" subtitle="Welcome back to ZEEN BAGS" />
          </div>
        </section>
        <section className="pb-20">
          <div className="mx-auto max-w-md px-4">
            <div className="glass-card rounded-2xl p-8 text-center">
              <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full border-2 border-gold bg-gold/10">
                <span className="font-display text-3xl font-bold text-gold">{user.name.charAt(0).toUpperCase()}</span>
              </div>
              <h3 className="mt-5 font-display text-2xl font-bold text-cream">{user.name}</h3>
              <p className="mt-1 text-cream/60">{user.email}</p>

              <div className="mt-6 grid grid-cols-2 gap-4">
                <button onClick={() => navigate('wishlist')} className="glass-light rounded-xl p-4 transition-all hover:border-gold">
                  <span className="font-display text-2xl font-bold text-gold">My</span>
                  <p className="mt-1 text-xs text-cream/60">Wishlist</p>
                </button>
                <button onClick={() => navigate('cart')} className="glass-light rounded-xl p-4 transition-all hover:border-gold">
                  <span className="font-display text-2xl font-bold text-gold">My</span>
                  <p className="mt-1 text-xs text-cream/60">Cart</p>
                </button>
              </div>

              <button onClick={logout} className="btn-outline-gold mt-6 w-full">
                Logout
              </button>
            </div>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div>
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title={mode === 'login' ? 'Welcome Back' : 'Create Account'} subtitle="Join the ZEEN BAGS family for exclusive offers" />
        </div>
      </section>

      <section className="pb-20">
        <div className="mx-auto max-w-md px-4">
          <div className="glass-card rounded-2xl p-8">
            {/* Toggle */}
            <div className="mb-6 flex rounded-full bg-cream/5 p-1">
              <button
                onClick={() => setMode('login')}
                className={`flex-1 rounded-full py-2.5 text-sm font-medium transition-all ${
                  mode === 'login' ? 'bg-gradient-to-r from-gold to-gold-light text-primary' : 'text-cream/60'
                }`}
              >
                Login
              </button>
              <button
                onClick={() => setMode('register')}
                className={`flex-1 rounded-full py-2.5 text-sm font-medium transition-all ${
                  mode === 'register' ? 'bg-gradient-to-r from-gold to-gold-light text-primary' : 'text-cream/60'
                }`}
              >
                Register
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'register' && (
                <div>
                  <label className="text-xs font-body text-cream/60">Full Name</label>
                  <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-gold/20 bg-cream/5 px-3 transition-all focus-within:border-gold">
                    <User size={18} className="text-gold/60" />
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Enter your name"
                      className="w-full bg-transparent py-3 text-cream placeholder:text-cream/40 focus:outline-none"
                    />
                  </div>
                  {errors.name && <p className="mt-1 text-xs text-red-400">{errors.name}</p>}
                </div>
              )}

              <div>
                <label className="text-xs font-body text-cream/60">Email Address</label>
                <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-gold/20 bg-cream/5 px-3 transition-all focus-within:border-gold">
                  <Mail size={18} className="text-gold/60" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full bg-transparent py-3 text-cream placeholder:text-cream/40 focus:outline-none"
                  />
                </div>
                {errors.email && <p className="mt-1 text-xs text-red-400">{errors.email}</p>}
              </div>

              <div>
                <label className="text-xs font-body text-cream/60">Password</label>
                <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-gold/20 bg-cream/5 px-3 transition-all focus-within:border-gold">
                  <Lock size={18} className="text-gold/60" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-transparent py-3 text-cream placeholder:text-cream/40 focus:outline-none"
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="text-cream/40 hover:text-gold">
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
                {errors.password && <p className="mt-1 text-xs text-red-400">{errors.password}</p>}
              </div>

              {mode === 'login' && (
                <div className="flex items-center justify-between text-xs">
                  <label className="flex items-center gap-2 text-cream/60">
                    <input type="checkbox" className="accent-gold" /> Remember me
                  </label>
                  <button type="button" className="text-gold hover:underline">Forgot password?</button>
                </div>
              )}

              <button type="submit" className="btn-gold w-full">
                {mode === 'login' ? 'Login' : 'Create Account'}
              </button>
            </form>

            <div className="my-6 flex items-center gap-3">
              <div className="h-px flex-1 bg-gold/15" />
              <span className="text-xs text-cream/40">or continue with</span>
              <div className="h-px flex-1 bg-gold/15" />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button className="flex items-center justify-center gap-2 rounded-xl border border-gold/20 bg-cream/5 py-3 text-sm text-cream/70 transition-all hover:border-gold hover:text-gold">
                Google
              </button>
              <button className="flex items-center justify-center gap-2 rounded-xl border border-gold/20 bg-cream/5 py-3 text-sm text-cream/70 transition-all hover:border-gold hover:text-gold">
                Facebook
              </button>
            </div>

            <p className="mt-6 text-center text-xs text-cream/50">
              <Sparkles size={12} className="mr-1 inline text-gold" />
              By continuing, you agree to our Terms & Privacy Policy
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
