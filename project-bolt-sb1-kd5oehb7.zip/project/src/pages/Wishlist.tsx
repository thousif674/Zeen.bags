import { Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { PRODUCTS } from '../data/products';
import ProductCard from '../components/ProductCard';
import { SectionHeading } from '../components/SectionHeading';

export default function Wishlist() {
  const { wishlist, navigate, addToCart, toggleWishlist } = useStore();

  const items = PRODUCTS.filter((p) => wishlist.includes(p.id));

  if (items.length === 0) {
    return (
      <div>
        <section className="py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <SectionHeading title="My Wishlist" subtitle="Your favorite handbags in one place" />
          </div>
        </section>
        <div className="flex min-h-[50vh] flex-col items-center justify-center px-4">
          <div className="flex h-24 w-24 items-center justify-center rounded-full border-2 border-gold/30 bg-gold/5">
            <Heart size={40} className="text-gold/50" />
          </div>
          <h3 className="mt-6 font-display text-2xl font-bold text-cream">Your wishlist is empty</h3>
          <p className="mt-2 text-cream/50">Save your favorite bags here for later.</p>
          <button onClick={() => navigate('shop')} className="btn-gold mt-6">
            Explore Collection
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title="My Wishlist" subtitle={`${items.length} ${items.length === 1 ? 'item' : 'items'} saved`} />
        </div>
      </section>

      <section className="pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {items.map((p) => (
              <div key={p.id} className="relative">
                <ProductCard product={p} />
                <button
                  onClick={() => toggleWishlist(p.id)}
                  className="absolute -right-2 -top-2 z-30 flex h-8 w-8 items-center justify-center rounded-full bg-red-500/90 text-white shadow-lg transition-transform hover:scale-110"
                  aria-label="Remove from wishlist"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>

          <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <button onClick={() => navigate('shop')} className="btn-outline-gold">
              Continue Shopping
            </button>
            <button
              onClick={() => items.forEach((p) => addToCart(p))}
              className="btn-gold flex items-center gap-2"
            >
              <ShoppingBag size={18} /> Add All to Cart
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
