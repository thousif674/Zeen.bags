import { useState } from 'react';
import { Search, ArrowRight, Star, Quote, Sparkles, Truck, Shield, Award, Headphones } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { PRODUCTS, CATEGORIES } from '../data/products';
import ProductCard from '../components/ProductCard';
import { SectionHeading, useReveal } from '../components/SectionHeading';

const reviews = [
  {
    name: 'Ananya Sharma',
    location: 'Mumbai',
    rating: 5,
    text: 'Absolutely in love with my ZEEN BAGS tote! The quality is incredible and it looks so premium. Worth every rupee.',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
  },
  {
    name: 'Priya Nair',
    location: 'Bengaluru',
    rating: 5,
    text: 'The craftsmanship is outstanding. I get compliments everywhere I go. Affordable luxury at its finest!',
    avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=150',
  },
  {
    name: 'Kavya Reddy',
    location: 'Hyderabad',
    rating: 4,
    text: 'Beautiful designs and fast delivery. The party bag I ordered was even prettier in person. Highly recommend!',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150',
  },
  {
    name: 'Sneha Patel',
    location: 'Ahmedabad',
    rating: 5,
    text: 'I have ordered 3 bags from ZEEN BAGS now and each one exceeds expectations. The leather quality is superb.',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150',
  },
];

const features = [
  { icon: Truck, title: 'Free Shipping', desc: 'On orders above ₹999' },
  { icon: Shield, title: 'Secure Payment', desc: '100% protected payments' },
  { icon: Award, title: 'Premium Quality', desc: 'Handcrafted with care' },
  { icon: Headphones, title: '24/7 Support', desc: 'Always here for you' },
];

export default function Home() {
  const { navigate, searchQuery, setSearchQuery } = useStore();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const ref = useReveal<HTMLDivElement>();

  const bestSellers = PRODUCTS.filter((p) => p.isBestSeller).slice(0, 4);
  const newArrivals = PRODUCTS.filter((p) => p.isNew).slice(0, 4);
  const trending = PRODUCTS.filter((p) => p.isTrending).slice(0, 4);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) navigate('shop');
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 3000);
    }
  };

  return (
    <div ref={ref}>
      {/* Hero */}
      <section className="relative flex min-h-[88vh] items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Luxury handbags"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 hero-overlay" />
        </div>

        <div className="relative z-10 mx-auto max-w-4xl px-4 text-center">
          <div className="animate-fade-down">
            <span className="inline-flex items-center gap-2 rounded-full glass-light px-5 py-2 text-xs font-body tracking-widest text-gold uppercase">
              <Sparkles size={14} /> Premium Indian Ladies' Handbags
            </span>
          </div>

          <h1 className="mt-6 animate-fade-up font-display text-5xl font-bold leading-tight text-cream md:text-7xl lg:text-8xl">
            Where <span className="text-gold-shimmer">Style</span><br />Meets Comfort
          </h1>

          <p className="mx-auto mt-6 max-w-2xl animate-fade-up font-body text-lg text-cream/70" style={{ animationDelay: '0.2s' }}>
            Discover our exquisite collection of handcrafted Indian ladies' handbags.
            Affordable luxury designed for the modern woman who deserves the best.
          </p>

          <div className="mt-8 flex animate-fade-up flex-col items-center justify-center gap-4 sm:flex-row" style={{ animationDelay: '0.4s' }}>
            <button onClick={() => navigate('shop')} className="btn-gold group flex items-center gap-2">
              Shop Collection
              <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
            </button>
            <button onClick={() => navigate('about')} className="btn-outline-gold">
              Our Story
            </button>
          </div>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="mx-auto mt-10 max-w-xl animate-fade-up" style={{ animationDelay: '0.6s' }}>
            <div className="flex items-center gap-2 rounded-full glass-card p-2">
              <div className="flex flex-1 items-center gap-2 pl-4">
                <Search size={18} className="text-gold/60" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search for your perfect bag..."
                  className="w-full bg-transparent py-2 font-body text-cream placeholder:text-cream/40 focus:outline-none"
                />
              </div>
              <button type="submit" className="btn-gold !py-2.5 !px-6 text-sm">
                Search
              </button>
            </div>
          </form>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-float">
          <div className="flex h-10 w-6 items-start justify-center rounded-full border-2 border-gold/50 p-1.5">
            <div className="h-2 w-1 rounded-full bg-gold" />
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="border-y border-gold/10 bg-primary-700/40 py-8">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 gap-6 lg:grid-cols-4">
            {features.map((f, i) => (
              <div key={i} className="reveal flex items-center gap-3" style={{ transitionDelay: `${i * 0.1}s` }}>
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-gold/30 bg-gold/5">
                  <f.icon size={22} className="text-gold" />
                </div>
                <div>
                  <h4 className="font-body text-sm font-semibold text-cream">{f.title}</h4>
                  <p className="text-xs text-cream/50">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Collections */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Featured Collections" subtitle="Explore our curated categories of premium handbags">
            <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-9">
              {CATEGORIES.map((cat, i) => (
                <button
                  key={cat}
                  onClick={() => navigate('shop')}
                  className="reveal group flex flex-col items-center gap-3"
                  style={{ transitionDelay: `${i * 0.05}s` }}
                >
                  <div className="flex h-20 w-20 items-center justify-center rounded-full border-2 border-gold/30 bg-gradient-to-br from-leather-light/40 to-primary-700/60 transition-all duration-500 group-hover:scale-110 group-hover:border-gold">
                    <span className="font-display text-2xl font-bold text-gold-gradient">
                      {cat.charAt(0)}
                    </span>
                  </div>
                  <span className="text-center font-body text-xs font-medium text-cream/70 transition-colors group-hover:text-gold">
                    {cat}
                  </span>
                </button>
              ))}
            </div>
          </SectionHeading>
        </div>
      </section>

      {/* Best Sellers */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Best Sellers" subtitle="Our most loved handbags, chosen by women across India" />
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {bestSellers.map((p, i) => (
              <div key={p.id} className="reveal" style={{ transitionDelay: `${i * 0.1}s` }}>
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Promo Banner */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="reveal relative overflow-hidden rounded-3xl glass-card">
            <div className="grid items-center gap-8 md:grid-cols-2">
              <div className="p-10 md:p-16">
                <span className="text-xs font-body tracking-widest text-gold uppercase">Limited Time Offer</span>
                <h3 className="mt-3 font-display text-4xl font-bold text-cream md:text-5xl">
                  Up to <span className="text-gold-shimmer">40% Off</span><br />Premium Collection
                </h3>
                <p className="mt-4 font-body text-cream/60">
                  Elevate your style with our exclusive range of handcrafted handbags. Premium quality at affordable prices.
                </p>
                <button onClick={() => navigate('shop')} className="btn-gold mt-6">
                  Shop Now
                </button>
              </div>
              <div className="relative h-64 md:h-full">
                <img
                  src="https://images.pexels.com/photos/904350/pexels-photo-904350.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Premium handbag"
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-primary-700 via-transparent to-transparent" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title="New Arrivals" subtitle="Fresh designs just landed — be the first to own them" />
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {newArrivals.map((p, i) => (
              <div key={p.id} className="reveal" style={{ transitionDelay: `${i * 0.1}s` }}>
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trending */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Trending Now" subtitle="The bags everyone is talking about this season" />
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {trending.map((p, i) => (
              <div key={p.id} className="reveal" style={{ transitionDelay: `${i * 0.1}s` }}>
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Customer Reviews */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title="What Our Customers Say" subtitle="Real stories from women who love ZEEN BAGS" />
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
            {reviews.map((r, i) => (
              <div key={i} className="reveal glass-card rounded-2xl p-6" style={{ transitionDelay: `${i * 0.1}s` }}>
                <Quote size={32} className="text-gold/40" />
                <div className="mt-3 flex gap-1">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <Star key={s} size={14} className={s < r.rating ? 'fill-gold text-gold' : 'text-cream/20'} />
                  ))}
                </div>
                <p className="mt-3 font-body text-sm leading-relaxed text-cream/70">"{r.text}"</p>
                <div className="mt-5 flex items-center gap-3">
                  <img src={r.avatar} alt={r.name} className="h-11 w-11 rounded-full object-cover ring-2 ring-gold/30" />
                  <div>
                    <h5 className="font-body text-sm font-semibold text-cream">{r.name}</h5>
                    <p className="text-xs text-cream/50">{r.location}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-20">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="reveal relative overflow-hidden rounded-3xl glass-card p-10 text-center md:p-16">
            <div className="absolute -right-20 -top-20 h-60 w-60 rounded-full bg-gold/10 blur-3xl" />
            <div className="absolute -bottom-20 -left-20 h-60 w-60 rounded-full bg-gold/10 blur-3xl" />
            <div className="relative">
              <Sparkles size={32} className="mx-auto text-gold" />
              <h3 className="mt-4 font-display text-3xl font-bold text-cream md:text-4xl">
                Join the <span className="text-gold-shimmer">ZEEN BAGS</span> Family
              </h3>
              <p className="mx-auto mt-3 max-w-xl font-body text-cream/60">
                Subscribe to get exclusive offers, early access to new arrivals, and 10% off your first order.
              </p>
              <form onSubmit={handleSubscribe} className="mx-auto mt-6 flex max-w-md flex-col gap-3 sm:flex-row">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  className="input-luxury"
                  required
                />
                <button type="submit" className="btn-gold whitespace-nowrap">
                  {subscribed ? 'Subscribed!' : 'Subscribe'}
                </button>
              </form>
              <p className="mt-3 text-xs text-cream/40">No spam, unsubscribe anytime.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
