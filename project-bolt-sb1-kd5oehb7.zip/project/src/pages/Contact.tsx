import { useState } from 'react';
import { Phone, MessageCircle, MapPin, Mail, User, Send, AlertTriangle, Clock } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { SectionHeading } from '../components/SectionHeading';

const WHATSAPP_NUMBER = '918248278649';
const PHONE = '+91 8248278649';

export default function Contact() {
  const { showToast } = useStore();
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!form.name.trim()) errs.name = 'Name is required';
    if (!form.email.trim()) errs.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) errs.email = 'Invalid email';
    if (!form.message.trim()) errs.message = 'Message is required';
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    showToast('Message sent! We will get back to you soon.');
    setForm({ name: '', email: '', subject: '', message: '' });
  };

  const reportProblem = () => {
    window.open(
      `https://wa.me/${WHATSAPP_NUMBER}?text=Hello%20ZEEN%20BAGS%2C%20I%20would%20like%20to%20report%20a%20problem.`,
      '_blank'
    );
  };

  return (
    <div>
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Get in Touch" subtitle="We would love to hear from you. Reach out anytime!" />
        </div>
      </section>

      {/* Contact cards */}
      <section className="pb-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            {/* Call */}
            <a
              href={`tel:${PHONE.replace(/\s/g, '')}`}
              className="glass-card group rounded-2xl p-6 text-center transition-all duration-500 hover:-translate-y-2"
            >
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-gold/30 bg-gold/5 transition-all group-hover:bg-gold group-hover:text-primary">
                <Phone size={26} className="text-gold transition-colors group-hover:text-primary" />
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold text-cream">Call Now</h3>
              <p className="mt-1 text-sm text-gold">{PHONE}</p>
              <p className="mt-1 text-xs text-cream/50">Mon-Sat, 9am - 8pm</p>
            </a>

            {/* WhatsApp */}
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}?text=Hello%20ZEEN%20BAGS%2C%20I%20have%20a%20question.`}
              target="_blank"
              rel="noopener noreferrer"
              className="glass-card group rounded-2xl p-6 text-center transition-all duration-500 hover:-translate-y-2"
            >
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-gold/30 bg-gold/5 transition-all group-hover:bg-gold group-hover:text-primary">
                <MessageCircle size={26} className="text-gold transition-colors group-hover:text-primary" />
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold text-cream">WhatsApp Chat</h3>
              <p className="mt-1 text-sm text-gold">{PHONE}</p>
              <p className="mt-1 text-xs text-cream/50">Fastest response</p>
            </a>

            {/* Email */}
            <a
              href="mailto:contact@zeenbags.com"
              className="glass-card group rounded-2xl p-6 text-center transition-all duration-500 hover:-translate-y-2"
            >
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-gold/30 bg-gold/5 transition-all group-hover:bg-gold group-hover:text-primary">
                <Mail size={26} className="text-gold transition-colors group-hover:text-primary" />
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold text-cream">Email Us</h3>
              <p className="mt-1 text-sm text-gold">contact@zeenbags.com</p>
              <p className="mt-1 text-xs text-cream/50">Reply within 24 hours</p>
            </a>
          </div>
        </div>
      </section>

      {/* Form + Map */}
      <section className="pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-2">
            {/* Form */}
            <div className="glass-card rounded-2xl p-8">
              <h3 className="font-display text-2xl font-bold text-gold">Send Us a Message</h3>
              <div className="gold-divider mt-3 w-20" />
              <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                <div>
                  <label className="text-xs font-body text-cream/60">Your Name</label>
                  <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-gold/20 bg-cream/5 px-3 transition-all focus-within:border-gold">
                    <User size={18} className="text-gold/60" />
                    <input
                      type="text"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="Enter your name"
                      className="w-full bg-transparent py-3 text-cream placeholder:text-cream/40 focus:outline-none"
                    />
                  </div>
                  {errors.name && <p className="mt-1 text-xs text-red-400">{errors.name}</p>}
                </div>

                <div>
                  <label className="text-xs font-body text-cream/60">Email Address</label>
                  <div className="mt-1.5 flex items-center gap-2 rounded-xl border border-gold/20 bg-cream/5 px-3 transition-all focus-within:border-gold">
                    <Mail size={18} className="text-gold/60" />
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="you@example.com"
                      className="w-full bg-transparent py-3 text-cream placeholder:text-cream/40 focus:outline-none"
                    />
                  </div>
                  {errors.email && <p className="mt-1 text-xs text-red-400">{errors.email}</p>}
                </div>

                <div>
                  <label className="text-xs font-body text-cream/60">Subject</label>
                  <input
                    type="text"
                    value={form.subject}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    placeholder="What is this about?"
                    className="input-luxury mt-1.5"
                  />
                </div>

                <div>
                  <label className="text-xs font-body text-cream/60">Message</label>
                  <textarea
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder="Tell us how we can help..."
                    rows={5}
                    className="input-luxury mt-1.5 resize-none"
                  />
                  {errors.message && <p className="mt-1 text-xs text-red-400">{errors.message}</p>}
                </div>

                <button type="submit" className="btn-gold flex w-full items-center justify-center gap-2">
                  <Send size={18} /> Send Message
                </button>
              </form>

              {/* Report a problem */}
              <div className="mt-6 border-t border-gold/10 pt-6">
                <button
                  onClick={reportProblem}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-red-500/30 bg-red-500/5 py-3 text-sm font-medium text-red-400 transition-all hover:border-red-500 hover:bg-red-500/10"
                >
                  <AlertTriangle size={18} /> Report a Problem
                </button>
              </div>
            </div>

            {/* Map + Info */}
            <div className="space-y-6">
              {/* Map placeholder */}
              <div className="glass-card overflow-hidden rounded-2xl">
                <div className="relative flex h-64 items-center justify-center bg-gradient-to-br from-leather-light/30 to-primary-700/50">
                  <div className="absolute inset-0 opacity-20" style={{
                    backgroundImage: 'linear-gradient(rgba(212,175,55,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(212,175,55,0.1) 1px, transparent 1px)',
                    backgroundSize: '30px 30px',
                  }} />
                  <div className="relative text-center">
                    <MapPin size={48} className="mx-auto text-gold animate-pulse-gold" />
                    <p className="mt-3 font-display text-lg font-semibold text-cream">ZEEN BAGS</p>
                    <p className="text-sm text-cream/60">India</p>
                    <p className="mt-1 text-xs text-cream/40">Google Map Integration Ready</p>
                  </div>
                </div>
              </div>

              {/* Owner info */}
              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-display text-lg font-semibold text-gold">Business Information</h3>
                <div className="gold-divider mt-3 w-20" />
                <div className="mt-5 space-y-4">
                  <div className="flex items-start gap-3">
                    <User size={18} className="mt-0.5 shrink-0 text-gold" />
                    <div>
                      <p className="text-xs text-cream/50">Owner</p>
                      <p className="font-body text-sm font-semibold text-cream">Safrin</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone size={18} className="mt-0.5 shrink-0 text-gold" />
                    <div>
                      <p className="text-xs text-cream/50">Phone</p>
                      <a href="tel:+918248278649" className="font-body text-sm font-semibold text-cream hover:text-gold">{PHONE}</a>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <MessageCircle size={18} className="mt-0.5 shrink-0 text-gold" />
                    <div>
                      <p className="text-xs text-cream/50">WhatsApp</p>
                      <a href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank" rel="noopener noreferrer" className="font-body text-sm font-semibold text-cream hover:text-gold">{PHONE}</a>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Clock size={18} className="mt-0.5 shrink-0 text-gold" />
                    <div>
                      <p className="text-xs text-cream/50">Business Hours</p>
                      <p className="font-body text-sm font-semibold text-cream">Mon - Sat: 9am - 8pm</p>
                      <p className="font-body text-sm text-cream/60">Sunday: 10am - 4pm</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
