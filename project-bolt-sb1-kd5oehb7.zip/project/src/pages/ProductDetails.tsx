import { useState } from 'react';
import { Star, Heart, ShoppingBag, Minus, Plus, Truck, Shield, RefreshCw, ChevronRight } from 'lucide-react';
import { useStore, getProductById } from '../context/StoreContext';
import { PRODUCTS, formatINR } from '../data/products';
import ProductCard from '../components/ProductCard';

export default function ProductDetails() {
  const { productId, navigate, addToCart, toggleWishlist, isWishlisted } = useStore();
  const product = getProductById(productId);

  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  const [activeTab, setActiveTab] = useState<'description' | 'reviews' | 'shipping'>('description');

  if (!product) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center">
        <p className="font-display text-2xl text-cream">Product not found</p>
        <button onClick={() => navigate('shop')} className="btn-gold mt-6">
          Back to Shop
        </button>
      </div>
    );
  }

  const wished = isWishlisted(product.id);
  const related = PRODUCTS.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);

  return (
    <div>
      {/* Breadcrumb */}
      <div className="mx-auto max-w-7xl px-4 pt-8 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 text-sm text-cream/50">
          <button onClick={() => navigate('home')} className="hover:text-gold">Home</button>
          <ChevronRight size={14} />
          <button onClick={() => navigate('shop')} className="hover:text-gold">Shop</button>
          <ChevronRight size={14} />
          <span className="text-gold">{product.name}</span>
        </div>
      </div>

      {/* Product */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-2">
            {/* Images */}
            <div className="animate-fade-up">
              <div className="relative overflow-hidden rounded-2xl glass-card">
                <img
                  src={product.images[activeImage]}
                  alt={product.name}
                  className="aspect-[4/5] w-full object-cover"
                />
                {product.discount > 0 && (
                  <span className="badge-discount">-{product.discount}%</span>
                )}
              </div>
              <div className="mt-4 grid grid-cols-4 gap-3">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`overflow-hidden rounded-xl border-2 transition-all ${
                      activeImage === i ? 'border-gold' : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt={`${product.name} ${i + 1}`} className="aspect-square w-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* Info */}
            <div className="animate-fade-up" style={{ animationDelay: '0.1s' }}>
              <p className="text-xs font-body tracking-widest text-gold uppercase">{product.category}</p>
              <h1 className="mt-2 font-display text-3xl font-bold text-cream md:text-4xl">{product.name}</h1>

              <div className="mt-3 flex items-center gap-3">
                <div className="flex gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      size={16}
                      className={i < Math.floor(product.rating) ? 'fill-gold text-gold' : 'text-cream/20'}
                    />
                  ))}
                </div>
                <span className="text-sm text-cream/60">{product.rating} ({product.reviews} reviews)</span>
              </div>

              <div className="mt-5 flex items-baseline gap-3">
                <span className="font-display text-4xl font-bold text-gold">{formatINR(product.price)}</span>
                <span className="text-xl text-cream/40 line-through">{formatINR(product.originalPrice)}</span>
                <span className="rounded-full bg-gold/15 px-3 py-1 text-sm font-semibold text-gold">
                  Save {formatINR(product.originalPrice - product.price)}
                </span>
              </div>

              <p className="mt-5 font-body leading-relaxed text-cream/70">{product.description}</p>

              {/* Colors */}
              <div className="mt-6">
                <h4 className="font-body text-sm font-semibold text-cream">Available Colors</h4>
                <div className="mt-2 flex gap-2">
                  {product.colors.map((c) => (
                    <span key={c} className="rounded-full border border-gold/30 px-3 py-1.5 text-xs text-cream/70">
                      {c}
                    </span>
                  ))}
                </div>
              </div>

              {/* Material */}
              <div className="mt-4">
                <h4 className="font-body text-sm font-semibold text-cream">Material</h4>
                <p className="mt-1 text-sm text-cream/60">{product.material}</p>
              </div>

              {/* Quantity */}
              <div className="mt-6">
                <h4 className="font-body text-sm font-semibold text-cream">Quantity</h4>
                <div className="mt-2 flex items-center gap-3">
                  <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="qty-btn">
                    <Minus size={16} />
                  </button>
                  <span className="w-12 text-center font-display text-lg font-semibold text-cream">{quantity}</span>
                  <button onClick={() => setQuantity(quantity + 1)} className="qty-btn">
                    <Plus size={16} />
                  </button>
                </div>
              </div>

              {/* Actions */}
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <button
                  onClick={() => addToCart(product, quantity)}
                  className="btn-gold flex flex-1 items-center justify-center gap-2"
                >
                  <ShoppingBag size={18} /> Add to Cart
                </button>
                <button
                  onClick={() => {
                    addToCart(product, quantity);
                    navigate('cart');
                  }}
                  className="btn-outline-gold flex-1"
                >
                  Buy Now
                </button>
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className={`flex h-12 w-12 items-center justify-center rounded-full border transition-all ${
                    wished ? 'border-gold bg-gold/10' : 'border-gold/30'
                  }`}
                >
                  <Heart size={20} className={wished ? 'fill-gold text-gold' : 'text-cream/70'} />
                </button>
              </div>

              {/* Trust badges */}
              <div className="mt-8 grid grid-cols-3 gap-4 border-t border-gold/10 pt-6">
                {[
                  { icon: Truck, label: 'Free Shipping', sub: 'Above ₹999' },
                  { icon: RefreshCw, label: '7-Day Returns', sub: 'Easy returns' },
                  { icon: Shield, label: 'Secure', sub: 'Safe checkout' },
                ].map((t, i) => (
                  <div key={i} className="flex flex-col items-center text-center">
                    <t.icon size={22} className="text-gold" />
                    <span className="mt-1.5 text-xs font-semibold text-cream">{t.label}</span>
                    <span className="text-[10px] text-cream/50">{t.sub}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="mt-16">
            <div className="flex gap-6 border-b border-gold/15">
              {[
                { key: 'description', label: 'Description' },
                { key: 'reviews', label: `Reviews (${product.reviews})` },
                { key: 'shipping', label: 'Shipping & Returns' },
              ].map((t) => (
                <button
                  key={t.key}
                  onClick={() => setActiveTab(t.key as typeof activeTab)}
                  className={`relative pb-3 font-body text-sm font-medium transition-colors ${
                    activeTab === t.key ? 'text-gold' : 'text-cream/50 hover:text-cream'
                  }`}
                >
                  {t.label}
                  {activeTab === t.key && (
                    <span className="absolute bottom-0 left-0 h-0.5 w-full bg-gradient-to-r from-gold to-gold-light" />
                  )}
                </button>
              ))}
            </div>

            <div className="mt-6 font-body leading-relaxed text-cream/70">
              {activeTab === 'description' && (
                <div className="max-w-3xl space-y-4">
                  <p>{product.description}</p>
                  <p>
                    Each {product.name} is meticulously handcrafted by skilled Indian artisans who take pride in every stitch.
                    The {product.material.toLowerCase()} construction ensures durability while maintaining a soft, luxurious feel.
                    Designed to complement both ethnic and contemporary outfits, this bag is a versatile addition to any wardrobe.
                  </p>
                  <ul className="space-y-2">
                    <li className="flex gap-2"><ChevronRight size={18} className="text-gold" /> Premium {product.material.toLowerCase()} construction</li>
                    <li className="flex gap-2"><ChevronRight size={18} className="text-gold" /> Spacious interior with multiple compartments</li>
                    <li className="flex gap-2"><ChevronRight size={18} className="text-gold" /> Gold-tone hardware accents</li>
                    <li className="flex gap-2"><ChevronRight size={18} className="text-gold" /> Available in {product.colors.join(', ')}</li>
                    <li className="flex gap-2"><ChevronRight size={18} className="text-gold" /> Designed and crafted in India</li>
                  </ul>
                </div>
              )}

              {activeTab === 'reviews' && (
                <div className="max-w-3xl space-y-4">
                  {[
                    { name: 'Ananya S.', rating: 5, text: 'Beautiful bag! Quality is amazing for this price range.' },
                    { name: 'Priya K.', rating: 5, text: 'Exactly as shown in the pictures. Very happy with my purchase.' },
                    { name: 'Meera R.', rating: 4, text: 'Lovely design and good material. Delivery was quick too.' },
                  ].map((r, i) => (
                    <div key={i} className="glass-card rounded-xl p-5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gold/15 font-display font-bold text-gold">
                            {r.name.charAt(0)}
                          </div>
                          <div>
                            <h5 className="font-body text-sm font-semibold text-cream">{r.name}</h5>
                            <div className="flex gap-0.5">
                              {Array.from({ length: 5 }).map((_, s) => (
                                <Star key={s} size={12} className={s < r.rating ? 'fill-gold text-gold' : 'text-cream/20'} />
                              ))}
                            </div>
                          </div>
                        </div>
                        <span className="text-xs text-cream/40">Verified Purchase</span>
                      </div>
                      <p className="mt-3 text-sm text-cream/70">{r.text}</p>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'shipping' && (
                <div className="max-w-3xl space-y-4">
                  <div>
                    <h5 className="font-display text-lg font-semibold text-gold">Shipping Policy</h5>
                    <p className="mt-2">We offer free shipping on all orders above ₹999. Orders are processed within 1-2 business days and typically delivered within 3-7 business days across India.</p>
                  </div>
                  <div>
                    <h5 className="font-display text-lg font-semibold text-gold">Return Policy</h5>
                    <p className="mt-2">We offer a 7-day easy return policy. If you're not satisfied with your purchase, return it for a full refund or exchange. Items must be unused and in original packaging.</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Related */}
          {related.length > 0 && (
            <div className="mt-16">
              <h3 className="mb-8 text-center font-display text-3xl font-bold text-gold-shimmer">You May Also Like</h3>
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
                {related.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
