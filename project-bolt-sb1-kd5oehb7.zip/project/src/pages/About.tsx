import { Award, Heart, Sparkles, Users, ShoppingBag, Quote } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { SectionHeading, useReveal } from '../components/SectionHeading';

const values = [
  { icon: Award, title: 'Quality Craftsmanship', desc: 'Every bag is handcrafted by skilled Indian artisans using premium materials and time-honored techniques.' },
  { icon: Heart, title: 'Affordable Luxury', desc: 'We believe luxury should be accessible. Our bags offer premium quality at prices that make sense.' },
  { icon: Sparkles, title: 'Elegant Design', desc: 'Each design is thoughtfully created to blend traditional Indian aesthetics with modern functionality.' },
  { icon: Users, title: 'Customer First', desc: 'Your satisfaction is our priority. We provide exceptional service and support at every step.' },
];

const stats = [
  { value: '50+', label: 'Unique Designs' },
  { value: '10K+', label: 'Happy Customers' },
  { value: '4.8★', label: 'Average Rating' },
  { value: '100%', label: 'Handcrafted' },
];

export default function About() {
  const { navigate } = useStore();
  const ref = useReveal<HTMLDivElement>();

  return (
    <div ref={ref}>
      {/* Hero */}
      <section className="relative flex min-h-[50vh] items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="About ZEEN BAGS"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 hero-overlay" />
        </div>
        <div className="relative z-10 mx-auto max-w-3xl px-4 text-center">
          <span className="inline-flex items-center gap-2 rounded-full glass-light px-5 py-2 text-xs font-body tracking-widest text-gold uppercase animate-fade-down">
            <Sparkles size={14} /> Our Story
          </span>
          <h1 className="mt-6 animate-fade-up font-display text-4xl font-bold text-cream md:text-6xl">
            The <span className="text-gold-shimmer">ZEEN BAGS</span> Journey
          </h1>
          <p className="mx-auto mt-4 max-w-2xl animate-fade-up font-body text-lg text-cream/70" style={{ animationDelay: '0.2s' }}>
            Crafting affordable luxury for the modern Indian woman, one handbag at a time.
          </p>
        </div>
      </section>

      {/* Story */}
      <section className="py-20">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="reveal glass-card rounded-3xl p-8 md:p-12">
            <h2 className="font-display text-3xl font-bold text-gold-shimmer">Where Style Meets Comfort</h2>
            <div className="gold-divider mt-3 w-20" />
            <div className="mt-6 space-y-4 font-body leading-relaxed text-cream/70">
              <p>
                ZEEN BAGS was born from a simple yet powerful vision: to bring premium, handcrafted ladies' handbags
                to every Indian woman without the premium price tag. Founded by <span className="text-gold font-semibold">Safrin</span>,
                our brand celebrates the rich heritage of Indian craftsmanship while embracing modern design sensibilities.
              </p>
              <p>
                Every handbag in our collection tells a story — of skilled artisans who pour their heart into every stitch,
                of timeless designs that transcend trends, and of the modern Indian woman who deserves to carry a piece
                of luxury wherever she goes. From elegant tote bags for the office to stunning party bags for special
                occasions, we offer something for every moment.
              </p>
              <p>
                What sets us apart is our unwavering commitment to <span className="text-gold font-semibold">affordable luxury</span>.
                We believe that quality craftsmanship shouldn't be a privilege reserved for a few. By working directly with
                artisans and maintaining honest pricing, we ensure that every woman can own a piece of premium luxury
                without compromise.
              </p>
              <p>
                Our handbags are more than just accessories — they are companions that carry your essentials, your confidence,
                and your story. Each piece is meticulously crafted using premium materials, designed to last, and made
                to make you feel extraordinary.
              </p>
              <p>
                At ZEEN BAGS, we don't just sell handbags. We celebrate the spirit of the Indian woman — her grace, her
                ambition, her style, and her comfort. Join us on this journey where every bag is a testament to the
                beauty of affordable luxury.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 gap-6 lg:grid-cols-4">
            {stats.map((s, i) => (
              <div key={i} className="reveal glass-card rounded-2xl p-6 text-center" style={{ transitionDelay: `${i * 0.1}s` }}>
                <p className="font-display text-4xl font-bold text-gold-shimmer">{s.value}</p>
                <p className="mt-2 text-sm text-cream/60">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Our Core Values" subtitle="The principles that guide everything we do" />
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
            {values.map((v, i) => (
              <div key={i} className="reveal glass-card rounded-2xl p-6 transition-all duration-500 hover:-translate-y-2" style={{ transitionDelay: `${i * 0.1}s` }}>
                <div className="flex h-14 w-14 items-center justify-center rounded-full border border-gold/30 bg-gold/5">
                  <v.icon size={26} className="text-gold" />
                </div>
                <h3 className="mt-4 font-display text-lg font-semibold text-cream">{v.title}</h3>
                <p className="mt-2 font-body text-sm leading-relaxed text-cream/60">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="py-20">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="reveal relative overflow-hidden rounded-3xl glass-card p-10 text-center md:p-16">
            <Quote size={48} className="mx-auto text-gold/30" />
            <p className="mt-4 font-display text-2xl font-medium leading-relaxed text-cream md:text-3xl">
              "Our mission is to make every Indian woman feel luxurious, confident, and comfortable —
              one beautifully crafted handbag at a time."
            </p>
            <p className="mt-6 font-body text-gold">— Safrin, Founder of ZEEN BAGS</p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="pb-20">
        <div className="mx-auto max-w-3xl px-4 text-center">
          <h3 className="font-display text-3xl font-bold text-cream">Ready to Find Your Perfect Bag?</h3>
          <p className="mt-3 text-cream/60">Explore our collection of 50 unique handbags, each crafted with love.</p>
          <div className="mt-6 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <button onClick={() => navigate('shop')} className="btn-gold flex items-center gap-2">
              <ShoppingBag size={18} /> Shop Now
            </button>
            <button onClick={() => navigate('contact')} className="btn-outline-gold">
              Get in Touch
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
