import { useMemo, useState } from 'react';
import { SlidersHorizontal, X, Star } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { PRODUCTS, CATEGORIES, formatINR } from '../data/products';
import ProductCard from '../components/ProductCard';
import { SectionHeading } from '../components/SectionHeading';

type SortOption = 'featured' | 'price-low' | 'price-high' | 'rating' | 'discount';

export default function Shop() {
  const { searchQuery, setSearchQuery } = useStore();
  const [selectedCats, setSelectedCats] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([499, 1999]);
  const [minRating, setMinRating] = useState(0);
  const [sort, setSort] = useState<SortOption>('featured');
  const [showFilters, setShowFilters] = useState(false);

  const toggleCat = (cat: string) => {
    setSelectedCats((prev) =>
      prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]
    );
  };

  const filtered = useMemo(() => {
    let result = PRODUCTS.filter((p) => {
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        if (!p.name.toLowerCase().includes(q) && !p.category.toLowerCase().includes(q)) {
          return false;
        }
      }
      if (selectedCats.length > 0 && !selectedCats.includes(p.category)) return false;
      if (p.price < priceRange[0] || p.price > priceRange[1]) return false;
      if (p.rating < minRating) return false;
      return true;
    });

    switch (sort) {
      case 'price-low':
        result = [...result].sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result = [...result].sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result = [...result].sort((a, b) => b.rating - a.rating);
        break;
      case 'discount':
        result = [...result].sort((a, b) => b.discount - a.discount);
        break;
    }

    return result;
  }, [searchQuery, selectedCats, priceRange, minRating, sort]);

  const clearFilters = () => {
    setSelectedCats([]);
    setPriceRange([499, 1999]);
    setMinRating(0);
    setSearchQuery('');
  };

  const FilterContent = () => (
    <div className="space-y-8">
      {/* Search */}
      <div>
        <h4 className="font-display text-sm font-semibold text-gold uppercase tracking-wider">Search</h4>
        <div className="gold-divider mt-2 w-12" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search bags..."
          className="input-luxury mt-3 !py-2 text-sm"
        />
      </div>

      {/* Categories */}
      <div>
        <h4 className="font-display text-sm font-semibold text-gold uppercase tracking-wider">Categories</h4>
        <div className="gold-divider mt-2 w-12" />
        <div className="mt-4 flex flex-wrap gap-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => toggleCat(cat)}
              className={`filter-chip ${selectedCats.includes(cat) ? 'active' : ''}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Price */}
      <div>
        <h4 className="font-display text-sm font-semibold text-gold uppercase tracking-wider">Price Range</h4>
        <div className="gold-divider mt-2 w-12" />
        <div className="mt-4 space-y-3">
          <div className="flex items-center justify-between text-sm text-cream/70">
            <span>{formatINR(priceRange[0])}</span>
            <span>{formatINR(priceRange[1])}</span>
          </div>
          <input
            type="range"
            min={499}
            max={1999}
            step={50}
            value={priceRange[1]}
            onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
            className="w-full accent-gold"
          />
          <div className="flex gap-2">
            {['₹499-₹999', '₹1000-₹1499', '₹1500-₹1999'].map((label, i) => (
              <button
                key={label}
                onClick={() => setPriceRange(i === 0 ? [499, 999] : i === 1 ? [1000, 1499] : [1500, 1999])}
                className="filter-chip !px-3 !py-1.5 !text-xs"
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Rating */}
      <div>
        <h4 className="font-display text-sm font-semibold text-gold uppercase tracking-wider">Minimum Rating</h4>
        <div className="gold-divider mt-2 w-12" />
        <div className="mt-4 space-y-2">
          {[0, 3, 4, 4.5].map((r) => (
            <button
              key={r}
              onClick={() => setMinRating(r)}
              className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm transition-all ${
                minRating === r ? 'bg-gold/10 text-gold' : 'text-cream/60 hover:bg-cream/5'
              }`}
            >
              {r === 0 ? (
                <span>All Ratings</span>
              ) : (
                <>
                  <Star size={14} className="fill-gold text-gold" />
                  <span>{r}+ Stars</span>
                </>
              )}
            </button>
          ))}
        </div>
      </div>

      <button onClick={clearFilters} className="btn-outline-gold w-full !py-2.5 text-sm">
        Clear All Filters
      </button>
    </div>
  );

  return (
    <div>
      {/* Page header */}
      <section className="relative py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading title="Shop Our Collection" subtitle="50 unique handbags — find your perfect match" />
        </div>
      </section>

      <section className="pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex gap-8">
            {/* Sidebar - Desktop */}
            <aside className="hidden w-72 shrink-0 lg:block">
              <div className="sticky top-28 glass-card rounded-2xl p-6">
                <div className="flex items-center gap-2">
                  <SlidersHorizontal size={18} className="text-gold" />
                  <h3 className="font-display text-lg font-semibold text-gold">Filters</h3>
                </div>
                <div className="gold-divider mt-3" />
                <div className="mt-6">
                  <FilterContent />
                </div>
              </div>
            </aside>

            {/* Products */}
            <div className="flex-1">
              {/* Toolbar */}
              <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setShowFilters(true)}
                    className="flex items-center gap-2 rounded-full glass-light px-4 py-2 text-sm text-cream lg:hidden"
                  >
                    <SlidersHorizontal size={16} /> Filters
                  </button>
                  <p className="font-body text-sm text-cream/60">
                    Showing <span className="font-semibold text-gold">{filtered.length}</span> products
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-cream/50">Sort by:</span>
                  <select
                    value={sort}
                    onChange={(e) => setSort(e.target.value as SortOption)}
                    className="input-luxury !w-auto !py-2 !px-3 text-sm"
                  >
                    <option value="featured">Featured</option>
                    <option value="price-low">Price: Low to High</option>
                    <option value="price-high">Price: High to Low</option>
                    <option value="rating">Top Rated</option>
                    <option value="discount">Biggest Discount</option>
                  </select>
                </div>
              </div>

              {/* Active filters */}
              {(selectedCats.length > 0 || searchQuery) && (
                <div className="mb-4 flex flex-wrap items-center gap-2">
                  {searchQuery && (
                    <span className="flex items-center gap-1.5 rounded-full bg-gold/10 px-3 py-1.5 text-xs text-gold">
                      Search: "{searchQuery}"
                      <button onClick={() => setSearchQuery('')}><X size={14} /></button>
                    </span>
                  )}
                  {selectedCats.map((c) => (
                    <span key={c} className="flex items-center gap-1.5 rounded-full bg-gold/10 px-3 py-1.5 text-xs text-gold">
                      {c}
                      <button onClick={() => toggleCat(c)}><X size={14} /></button>
                    </span>
                  ))}
                </div>
              )}

              {/* Grid */}
              {filtered.length > 0 ? (
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3">
                  {filtered.map((p) => (
                    <ProductCard key={p.id} product={p} />
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center rounded-2xl glass-card py-20 text-center">
                  <p className="font-display text-2xl text-cream">No products found</p>
                  <p className="mt-2 text-cream/50">Try adjusting your filters</p>
                  <button onClick={clearFilters} className="btn-gold mt-6">
                    Clear Filters
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Mobile filter drawer */}
      {showFilters && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowFilters(false)} />
          <div className="absolute left-0 top-0 h-full w-80 max-w-[85vw] overflow-y-auto glass border-r border-gold/20 p-6 animate-slide-in-left">
            <div className="mb-6 flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold text-gold">Filters</h3>
              <button onClick={() => setShowFilters(false)} className="text-cream/60 hover:text-gold">
                <X size={24} />
              </button>
            </div>
            <FilterContent />
          </div>
        </div>
      )}
    </div>
  );
}
