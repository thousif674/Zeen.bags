import { Heart, Eye, ShoppingBag, Star } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { formatINR, type Product } from '../data/products';

interface Props {
  product: Product;
}

export default function ProductCard({ product }: Props) {
  const { navigate, addToCart, toggleWishlist, isWishlisted } = useStore();
  const wished = isWishlisted(product.id);

  return (
    <div className="product-card group">
      {/* Image */}
      <div className="product-img-wrap relative aspect-[4/5] overflow-hidden rounded-t-2xl">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="product-img h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-primary-600/60 via-transparent to-transparent" />

        {/* Badges */}
        {product.discount > 0 && (
          <span className="badge-discount">-{product.discount}%</span>
        )}
        {product.isNew && (
          <span className="badge-new right-3 left-auto top-3">NEW</span>
        )}

        {/* Wishlist heart */}
        <button
          onClick={() => toggleWishlist(product.id)}
          className="absolute right-3 top-3 z-20 flex h-9 w-9 items-center justify-center rounded-full glass-light transition-all duration-300 hover:scale-110"
          aria-label="Add to wishlist"
        >
          <Heart
            size={16}
            className={wished ? 'fill-gold text-gold' : 'text-cream/80'}
          />
        </button>

        {/* Quick Actions */}
        <div className="quick-actions">
          <button
            onClick={() => addToCart(product)}
            className="quick-action-btn"
            aria-label="Add to cart"
            title="Add to Cart"
          >
            <ShoppingBag size={18} />
          </button>
          <button
            onClick={() => navigate('product', product.id)}
            className="quick-action-btn"
            aria-label="Quick view"
            title="Quick View"
          >
            <Eye size={18} />
          </button>
          <button
            onClick={() => toggleWishlist(product.id)}
            className="quick-action-btn"
            aria-label="Wishlist"
            title="Wishlist"
          >
            <Heart size={18} className={wished ? 'fill-primary' : ''} />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <p className="text-[11px] font-body tracking-widest text-gold/70 uppercase">{product.category}</p>
        <h3
          onClick={() => navigate('product', product.id)}
          className="mt-1 cursor-pointer font-display text-base font-semibold text-cream transition-colors hover:text-gold"
        >
          {product.name}
        </h3>

        {/* Rating */}
        <div className="mt-1.5 flex items-center gap-1">
          <Star size={13} className="fill-gold text-gold" />
          <span className="text-xs font-medium text-gold">{product.rating}</span>
          <span className="text-xs text-cream/40">({product.reviews})</span>
        </div>

        {/* Price */}
        <div className="mt-2 flex items-baseline gap-2">
          <span className="font-display text-lg font-bold text-gold">{formatINR(product.price)}</span>
          <span className="text-sm text-cream/40 line-through">{formatINR(product.originalPrice)}</span>
        </div>

        {/* Add to cart */}
        <button
          onClick={() => addToCart(product)}
          className="btn-gold mt-3 w-full !py-2.5 text-sm"
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}
