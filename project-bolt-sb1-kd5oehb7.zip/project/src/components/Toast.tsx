import { CheckCircle2 } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export default function Toast() {
  const { toast } = useStore();

  if (!toast) return null;

  return (
    <div className="fixed bottom-8 left-1/2 z-[100] -translate-x-1/2 animate-fade-up">
      <div className="glass-card flex items-center gap-3 rounded-full px-6 py-3.5 shadow-2xl">
        <CheckCircle2 size={20} className="text-gold" />
        <span className="font-body text-sm font-medium text-cream">{toast}</span>
      </div>
    </div>
  );
}
