import { useEffect, useRef, type ReactNode } from 'react';

export function useReveal<T extends HTMLElement>() {
  const ref = useRef<T>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('active');
          }
        });
      },
      { threshold: 0.1 }
    );

    const elements = el.querySelectorAll('.reveal');
    elements.forEach((e) => observer.observe(e));

    return () => observer.disconnect();
  }, []);

  return ref;
}

export function SectionHeading({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children?: ReactNode;
}) {
  return (
    <div className="mb-12">
      <div className="flex items-center justify-center gap-4">
        <div className="hidden h-px w-16 bg-gradient-to-r from-transparent to-gold sm:block" />
        <h2 className="section-title text-gold-shimmer">{title}</h2>
        <div className="hidden h-px w-16 bg-gradient-to-l from-transparent to-gold sm:block" />
      </div>
      {subtitle && <p className="section-subtitle">{subtitle}</p>}
      {children}
    </div>
  );
}
