import { useEffect, useState } from 'react';
import { Menu, X, Search, Heart, ShoppingBag, User } from 'lucide-react';
import { useStore, type Page } from '../context/StoreContext';

const navItems: { label: string; page: Page }[] = [
  { label: 'Home', page: 'home' },
  { label: 'Shop', page: 'shop' },
  { label: 'About', page: 'about' },
  { label: 'FAQ', page: 'faq' },
  { label: 'Contact', page: 'contact' },
];

export default function Navbar() {
  const { page, navigate, cartCount, wishlist, searchQuery, setSearchQuery, user } = useStore();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const go = (p: Page) => {
    navigate(p);
    setMobileOpen(false);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate('shop');
      setSearchOpen(false);
      setMobileOpen(false);
    }
  };

  return (
    <>
      {/* Announcement Bar */}
      <div className="relative z-40 overflow-hidden bg-gradient-to-r from-primary-700 via-leather-light to-primary-700 border-b border-gold/20">
        <div className="marquee py-2.5">
          <div className="marquee-content">
            {Array(2).fill(0).map((_, i) => (
              <div key={i} className="flex items-center gap-12 px-6 text-xs font-body tracking-widest text-gold/90 uppercase">
                <span>Free Shipping on Orders Above ₹999</span>
                <span className="text-gold/40">✦</span>
                <span>New Arrivals Every Week</span>
                <span className="text-gold/40">✦</span>
                <span>Use Code ZEEN10 for 10% Off</span>
                <span className="text-gold/40">✦</span>
                <span>Handcrafted in India</span>
                <span className="text-gold/40">✦</span>
                <span>Affordable Luxury for Every Woman</span>
                <span className="text-gold/40">✦</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Navbar */}
      <nav
        className={`sticky top-0 z-50 transition-all duration-500 ${
          scrolled ? 'glass shadow-lg shadow-black/30' : 'bg-transparent'
        }`}
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-20 items-center justify-between">
            {/* Logo */}
            <button onClick={() => go('home')} className="flex items-center gap-2">
              <div className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-gold">
                <span className="font-display text-xl font-bold text-gold-gradient">Z</span>
              </div>
              <div className="flex flex-col leading-none">
                <span className="font-display text-xl font-bold tracking-wider text-gold-gradient">ZEEN BAGS</span>
                <span className="text-[10px] font-body tracking-[0.2em] text-cream/50 uppercase">Where Style Meets Comfort</span>
              </div>
            </button>

            {/* Desktop Nav */}
            <div className="hidden items-center gap-8 lg:flex">
              {navItems.map((item) => (
                <button
                  key={item.page}
                  onClick={() => go(item.page)}
                  className={`nav-link ${page === item.page ? 'active' : ''}`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 sm:gap-4">
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className="flex h-10 w-10 items-center justify-center rounded-full text-cream/80 transition-colors hover:text-gold"
                aria-label="Search"
              >
                <Search size={20} />
              </button>

              <button
                onClick={() => go('wishlist')}
                className="relative flex h-10 w-10 items-center justify-center rounded-full text-cream/80 transition-colors hover:text-gold"
                aria-label="Wishlist"
              >
                <Heart size={20} />
                {wishlist.length > 0 && (
                  <span className="absolute -right-0.5 -top-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-gold text-[10px] font-bold text-primary">
                    {wishlist.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => go('cart')}
                className="relative flex h-10 w-10 items-center justify-center rounded-full text-cream/80 transition-colors hover:text-gold"
                aria-label="Cart"
              >
                <ShoppingBag size={20} />
                {cartCount > 0 && (
                  <span className="absolute -right-0.5 -top-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-gold text-[10px] font-bold text-primary">
                    {cartCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => go('login')}
                className="hidden h-10 w-10 items-center justify-center rounded-full text-cream/80 transition-colors hover:text-gold sm:flex"
                aria-label="Account"
              >
                <User size={20} />
              </button>

              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="flex h-10 w-10 items-center justify-center rounded-full text-cream lg:hidden"
                aria-label="Menu"
              >
                {mobileOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Search Bar */}
          {searchOpen && (
            <div className="animate-fade-down pb-4">
              <form onSubmit={handleSearch} className="flex gap-2">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search for handbags, categories..."
                  className="input-luxury"
                  autoFocus
                />
                <button type="submit" className="btn-gold whitespace-nowrap">
                  Search
                </button>
              </form>
            </div>
          )}
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="animate-fade-down glass border-t border-gold/20 lg:hidden">
            <div className="flex flex-col gap-1 px-4 py-4">
              {navItems.map((item) => (
                <button
                  key={item.page}
                  onClick={() => go(item.page)}
                  className={`rounded-lg px-4 py-3 text-left font-body text-base transition-colors ${
                    page === item.page ? 'bg-gold/10 text-gold' : 'text-cream/80 hover:bg-cream/5 hover:text-gold'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              <button
                onClick={() => go('login')}
                className={`rounded-lg px-4 py-3 text-left font-body text-base transition-colors ${
                  page === 'login' ? 'bg-gold/10 text-gold' : 'text-cream/80 hover:bg-cream/5 hover:text-gold'
                }`}
              >
                {user ? `Hi, ${user.name}` : 'Login / Register'}
              </button>
            </div>
          </div>
        )}
      </nav>
    </>
  );
}
