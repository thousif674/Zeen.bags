import { useState } from 'react';
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from 'lucide-react';
import { useStore, type Page } from '../context/StoreContext';

const quickLinks: { label: string; page: Page }[] = [
  { label: 'Home', page: 'home' },
  { label: 'Shop', page: 'shop' },
  { label: 'About Us', page: 'about' },
  { label: 'FAQ', page: 'faq' },
  { label: 'Contact Us', page: 'contact' },
  { label: 'Wishlist', page: 'wishlist' },
  { label: 'Shopping Cart', page: 'cart' },
  { label: 'Login / Register', page: 'login' },
];

const policies = ['Privacy Policy', 'Return Policy', 'Shipping Policy', 'Terms & Conditions'];

export default function Footer() {
  const { navigate } = useStore();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 3000);
    }
  };

  return (
    <footer className="relative mt-20 border-t border-gold/20 bg-primary-700/80 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-gold">
                <span className="font-display text-xl font-bold text-gold-gradient">Z</span>
              </div>
              <div className="flex flex-col leading-none">
                <span className="font-display text-xl font-bold tracking-wider text-gold-gradient">ZEEN BAGS</span>
                <span className="text-[10px] font-body tracking-[0.2em] text-cream/50 uppercase">Where Style Meets Comfort</span>
              </div>
            </div>
            <p className="mt-4 font-body text-sm leading-relaxed text-cream/60">
              Premium Indian ladies' handbags crafted with passion. Affordable luxury, elegant designs, and exceptional quality for the modern woman.
            </p>
            <div className="mt-6 flex gap-3">
              {[Facebook, Instagram, Twitter, Youtube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-gold/30 text-gold/80 transition-all duration-300 hover:border-gold hover:bg-gold hover:text-primary"
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-display text-lg font-semibold text-gold">Quick Links</h3>
            <div className="gold-divider mt-3 w-16" />
            <ul className="mt-5 space-y-2.5">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => navigate(link.page)}
                    className="font-body text-sm text-cream/60 transition-colors hover:text-gold hover:pl-1"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Policies */}
          <div>
            <h3 className="font-display text-lg font-semibold text-gold">Policies</h3>
            <div className="gold-divider mt-3 w-16" />
            <ul className="mt-5 space-y-2.5">
              {policies.map((p) => (
                <li key={p}>
                  <a
                    href="#"
                    onClick={(e) => e.preventDefault()}
                    className="font-body text-sm text-cream/60 transition-colors hover:text-gold hover:pl-1"
                  >
                    {p}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact + Newsletter */}
          <div>
            <h3 className="font-display text-lg font-semibold text-gold">Get in Touch</h3>
            <div className="gold-divider mt-3 w-16" />
            <ul className="mt-5 space-y-3">
              <li className="flex items-start gap-2 font-body text-sm text-cream/60">
                <MapPin size={16} className="mt-0.5 shrink-0 text-gold" />
                <span>Owner: Safrin, India</span>
              </li>
              <li className="flex items-center gap-2 font-body text-sm text-cream/60">
                <Phone size={16} className="shrink-0 text-gold" />
                <a href="tel:+918248278649" className="hover:text-gold">+91 8248278649</a>
              </li>
              <li className="flex items-center gap-2 font-body text-sm text-cream/60">
                <Mail size={16} className="shrink-0 text-gold" />
                <a href="mailto:contact@zeenbags.com" className="hover:text-gold">contact@zeenbags.com</a>
              </li>
            </ul>

            <form onSubmit={handleSubscribe} className="mt-5">
              <p className="mb-2 font-body text-xs text-cream/50">Subscribe to our newsletter</p>
              <div className="flex gap-2">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email"
                  className="input-luxury !py-2 !px-3 text-sm"
                  required
                />
                <button type="submit" className="btn-gold whitespace-nowrap !px-4 !py-2 text-sm">
                  {subscribed ? 'Subscribed!' : 'Join'}
                </button>
              </div>
            </form>
          </div>
        </div>

        <div className="gold-divider mt-12" />

        <div className="mt-6 flex flex-col items-center justify-between gap-4 sm:flex-row">
          <p className="font-body text-sm text-cream/50">
            Copyright © 2026 <span className="text-gold">ZEEN BAGS</span>. All rights reserved.
          </p>
          <p className="font-body text-xs text-cream/40">
            Handcrafted with love in India 🇮🇳
          </p>
        </div>
      </div>
    </footer>
  );
}
