import { useEffect, useState } from 'react';

export default function Loader() {
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setHidden(true), 1500);
    return () => clearTimeout(timer);
  }, []);

  if (hidden) return null;

  return (
    <div className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-primary-700 transition-opacity duration-700" style={{ opacity: hidden ? 0 : 1 }}>
      <div className="relative">
        <div className="luxury-loader" />
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-display text-lg font-bold text-gold">Z</span>
        </div>
      </div>
      <h1 className="mt-6 font-display text-2xl font-bold tracking-wider text-gold-gradient">ZEEN BAGS</h1>
      <p className="mt-1 text-xs font-body tracking-[0.3em] text-cream/50 uppercase">Where Style Meets Comfort</p>
    </div>
  );
}
