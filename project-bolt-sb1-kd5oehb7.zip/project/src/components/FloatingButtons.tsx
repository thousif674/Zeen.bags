import { useEffect, useState } from 'react';
import { ArrowUp, MessageCircle } from 'lucide-react';

const WHATSAPP_NUMBER = '918248278649';

export default function FloatingButtons() {
  const [showScroll, setShowScroll] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowScroll(window.scrollY > 400);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      {/* Scroll to top */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className={`scroll-top ${showScroll ? 'visible' : ''}`}
        aria-label="Scroll to top"
      >
        <ArrowUp size={22} />
      </button>

      {/* WhatsApp */}
      <a
        href={`https://wa.me/${WHATSAPP_NUMBER}?text=Hello%20ZEEN%20BAGS%2C%20I%20have%20a%20question.`}
        target="_blank"
        rel="noopener noreferrer"
        className="whatsapp-float"
        aria-label="Chat on WhatsApp"
      >
        <MessageCircle size={28} color="#fff" />
      </a>
    </>
  );
}
